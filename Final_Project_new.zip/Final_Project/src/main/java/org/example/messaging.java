package org.example;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class messaging {

    void displayForums(Connection connection) {
        try {
            String query = "SELECT forum_id, forum_name FROM forum";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int forumId = resultSet.getInt("forum_id");
                String forumName = resultSet.getString("forum_name");
                System.out.println("Forum ID: " + forumId + ", Forum Name: " + forumName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to retrieve forums.");
        }
    }
    public void postMessage(Connection connection, int userId, Scanner scanner) {
        try {
            System.out.println("Enter the subject of the message:");
            String subject = scanner.nextLine();
            System.out.println("Enter the body of the message:");
            String body = scanner.nextLine();

            // Display available forums and prompt user to select one
            System.out.println("Available Forums:");
            displayForums(connection);
            System.out.print("Enter the forum ID to post the message: ");
            int forumId = scanner.nextInt();
            scanner.nextLine();

            // Insert the message into the database
            String insertMessageSql = "INSERT INTO new_message (msg_subject, msg_body, creator_id, creation_date, forum_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertMessageStmt = connection.prepareStatement(insertMessageSql);
            insertMessageStmt.setString(1, subject);
            insertMessageStmt.setString(2, body);
            insertMessageStmt.setInt(3, userId);
            insertMessageStmt.setDate(4, new java.sql.Date(System.currentTimeMillis()));
            insertMessageStmt.setInt(5, forumId);
            insertMessageStmt.executeUpdate();

            // Get the generated message ID
            ResultSet generatedKeys = insertMessageStmt.getGeneratedKeys();
            //int messageId = -1;
//            if (generatedKeys.next()) {
//                messageId = generatedKeys.getInt(1);
//            }
//
//            if (messageId != -1) {
//                // Insert the message recipients into the msg_recipient table
//                // ...
//
//                System.out.println("Message posted successfully!");
//            } else {
//                System.out.println("Failed to post the message.");
//            }
            if (generatedKeys.next()) {
                int generatedMsgId = generatedKeys.getInt(1);
                System.out.println("Message posted successfully. Message ID: " + generatedMsgId);
            } else {
                System.out.println("Failed to post the message.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to post the message.");
        }
    }


    public void displayMessagesInForum(Connection connection, int forumId) {
        try {
            String query = "SELECT m.new_msg_id, m.msg_subject, m.msg_body, m.creator_id, u.first_name, u.last_name " +
                    "FROM new_message m " +
                    "INNER JOIN users u ON m.creator_id = u.user_id " +
                    "WHERE m.forum_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, forumId);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println("*************************************");
            System.out.println("Messages in Forum " + forumId + ":");
            while (resultSet.next()) {
                int messageId = resultSet.getInt("new_msg_id");
                String subject = resultSet.getString("msg_subject");
                String body = resultSet.getString("msg_body");
                int creatorId = resultSet.getInt("creator_id");
                String fullName = resultSet.getString("first_name") + " " + resultSet.getString("last_name");

                System.out.println("Message ID: " + messageId);
                System.out.println("Subject: " + subject);
                System.out.println("Body: " + body);
                System.out.println("Posted by User ID: " + creatorId);
                System.out.println("Posted by: " + fullName);
                System.out.println();
                System.out.println();
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to retrieve messages from the forum.");
        }
    }


}

