package org.example;

public class extraCode {
    /*
    //Send message to single recipient
    public void sendMessageToRecipient(Connection connection, int messageId, int recipientId) {
        try {
            String insertRecipientSql = "INSERT INTO msg_recipient (msg_id, recipient_id, is_read) VALUES (?, ?, ?)";
            PreparedStatement insertRecipientStmt = connection.prepareStatement(insertRecipientSql);
            insertRecipientStmt.setInt(1, messageId);
            insertRecipientStmt.setInt(2, recipientId);
            insertRecipientStmt.setBoolean(3, false); // Message is initially unread
            insertRecipientStmt.executeUpdate();

            System.out.println("Message sent to recipient successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to send message to recipient.");
        }
    }
    //Send msg to multiple recipients of a particular forum
    public void sendMessageToForum(Connection connection, int messageId, int forumId) {
        // Retrieve user IDs from user_forum for the specified forum
        List<Integer> recipientIds = getUserIdsInForum(connection, forumId);

        // Insert records into msg_recipient for each recipient
        for (int recipientId : recipientIds) {
            sendMessageToRecipient(connection, messageId, recipientId);
        }

        System.out.println("Message sent to forum successfully!");
    }

    private List<Integer> getUserIdsInForum(Connection connection, int forumId) {
        List<Integer> userIds = new ArrayList<>();
        try {
            String query = "SELECT user_id FROM user_forum WHERE forum_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, forumId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int userId = resultSet.getInt("user_id");
                userIds.add(userId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to retrieve user IDs in forum.");
        }
        return userIds;
    }

     */
}
