package org.example;

import java.sql.*;

import java.util.Scanner;

public class controlFlow {
    Scanner scanner = new Scanner(System.in);
    //dbConnect d2 = new dbConnect();
    userManager um = new userManager();
    messaging m = new messaging();
    replyMsg rm = new replyMsg();
    public void runApp(Connection c){
        try(Scanner scanner = new Scanner(System.in)){
            System.out.println("Welcome to the Messaging Forum!");
            int userId = userAccount(c);
            if(userId==-1){
                System.out.println("Registration/Login failed");
                System.exit(0);
            }

            while (true) {
                System.out.println("\nMain Menu:");
                System.out.println("1. Send a Message");
                System.out.println("2. Reply to a Message");
                System.out.println("3. View a Message");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        sendMsg(c,userId);
                        break;
                    case 2:
                        replyToMsg(c,userId,scanner);
                        break;
                    case 3:
                        System.out.print("Enter forum ID: ");
                        int fc = scanner.nextInt();
                        scanner.nextLine();
                        viewMsg(c,fc); //needs to be changed to forum ID
                        break;
                    case 4:
                        System.out.println("Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }


        }

    }

    public int userAccount(Connection c){


        System.out.println("Select type of user\n");
        System.out.println("1. Existing");
        System.out.println("2. New");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                return um.login(c, scanner);
            case 2:
                return um.register(c,scanner);
            default:
                System.out.println("Invalid choice. Please try again.");
        }

//        if(choice == 1) return um.login(d2.c , scanner);
//        else if

        return -1;
    }

    public void sendMsg(Connection con, int userId){

        System.out.println("Which forum do you want to post the message in?");
        int fid = scanner.nextInt();
        scanner.nextLine();

        m.postMessage(con,userId,scanner);

        System.out.println("Do you want to see the msg that you just posted?");
        System.out.println("1. Yes");
        System.out.println("2. No");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                viewMsg(con,fid);
            case 2:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }

    }

    public void viewMsg(Connection con,int forumID){

        m.displayMessagesInForum(con,forumID);

    }

    public void replyToMsg(Connection con,int userId,Scanner scanner){

        rm.replyToMessage(con,userId,scanner);
    }

}
